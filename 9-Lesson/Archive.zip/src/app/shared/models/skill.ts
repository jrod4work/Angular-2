import { Level } from '../types/level.enum';

export class Skill {
  id: number;
  name: string;
  level: Level;
}